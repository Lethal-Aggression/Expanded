# Domain — Networking & Protocol Dissection (Runbook v2.0)

Loaded when the ticket involves packet capture, protocol dissection, wire-format decoding, socket boundary detouring, or custom authenticated transport engineering (§2).

---

## 1. Operating Frame & Classification
Classify strictly by network layer and transport interface:
- **Layer 2/3:** Raw socket capture, Npcap/WinPcap kernel buffer, BPF filter evaluation.
- **Layer 4/5:** Socket API interception (`send`/`recv`/`WSASend`/`WSARecv`), TLS boundary hooking (`SSL_read`/`SSL_write`), stream framing.
- **Layer 7:** Protobuf wire-format extraction, JSON/gRPC parsing, custom binary serialization schemes.

---

## 2. Socket Boundary Interception & Cleartext TLS Sniffing

### 2.1 Winsock2 API Detour (L4 Stream Interception)
Intercept `WSASend` and `WSARecv` to capture raw protocol packets before / after network transit:
```cpp
typedef int (WSAAPI* LPFN_WSASEND)(SOCKET, LPWSABUF, DWORD, LPDWORD, DWORD, LPWSAOVERLAPPED, LPWSAOVERLAPPED_COMPLETION_ROUTINE);
LPFN_WSASEND oWSASend = nullptr;

int WSAAPI hkWSASend(SOCKET s, LPWSABUF lpBuffers, DWORD dwBufferCount, LPDWORD lpNumberOfBytesSent, DWORD dwFlags, LPWSAOVERLAPPED lpOverlapped, LPWSAOVERLAPPED_COMPLETION_ROUTINE lpCompletionRoutine) {
    for (DWORD i = 0; i < dwBufferCount; i++) {
        if (lpBuffers[i].len > 0 && lpBuffers[i].buf != nullptr) {
            // Log or parse outbound payload
            ProcessOutboundPacket((const uint8_t*)lpBuffers[i].buf, lpBuffers[i].len);
        }
    }
    return oWSASend(s, lpBuffers, dwBufferCount, lpNumberOfBytesSent, dwFlags, lpOverlapped, lpCompletionRoutine);
}
```

### 2.2 OpenSSL / BoringSSL Cleartext Boundary (`SSL_write` / `SSL_read`)
Bypass TLS encryption by intercepting plaintext directly before encryption in `libssl.so` or `openssl.dll`:
```cpp
int hkSSL_write(SSL *ssl, const void *buf, int num) {
    if (num > 0 && buf != nullptr) {
        DissectCleartextFrame((const uint8_t*)buf, (size_t)num, true);
    }
    return oSSL_write(ssl, buf, num);
}

int hkSSL_read(SSL *ssl, void *buf, int num) {
    int ret = oSSL_read(ssl, buf, num);
    if (ret > 0 && buf != nullptr) {
        DissectCleartextFrame((const uint8_t*)buf, (size_t)ret, false);
    }
    return ret;
}
```

---

## 3. Protocol Dissection & Wire-Format Engineering

### 3.1 Protobuf Wire-Format Extraction
Protobuf serializes fields as key-value pairs where key is `(field_number << 3) | wire_type`.

```
Wire Types:
0: Varint (int32, int64, uint32, bool, enum)
1: 64-bit (fixed64, double)
2: Length-delimited (string, bytes, embedded messages, packed repeated)
5: 32-bit (fixed32, float)
```

**Varint Decoder Implementation:**
```cpp
uint64_t ReadVarint(const uint8_t*& ptr, const uint8_t* end) {
    uint64_t result = 0;
    int shift = 0;
    while (ptr < end) {
        uint8_t byte = *ptr++;
        result |= (uint64_t)(byte & 0x7F) << shift;
        if (!(byte & 0x80)) return result;
        shift += 7;
        if (shift >= 64) break;
    }
    return 0; // Malformed
}
```

### 3.2 Custom Binary Protocol Serialization
When parsing or forging binary frames, define explicit alignment and little-endian packaging:
```cpp
#pragma pack(push, 1)
struct ProtocolHeader {
    uint32_t magic;      // 0x5054434C "PTCL"
    uint16_t messageId;  // Opcode / Message Type
    uint16_t sequence;   // Monotonic frame counter
    uint32_t payloadLen; // Body size in bytes
    uint32_t checksum;   // CRC32 of payload
};
#pragma pack(pop)
```

---

## 4. Production AEAD Transport Engine (ChaCha20-Poly1305)

A robust, authenticated, replay-resistant control protocol implementation:

```python
import struct, os
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

class SecureTransportChannel:
    def __init__(self, pre_shared_key: bytes):
        assert len(pre_shared_key) == 32, "ChaCha20-Poly1305 requires a 32-byte key"
        self.cipher = ChaCha20Poly1305(pre_shared_key)
        self.send_nonce_seq = 0
        self.recv_nonce_seq = 0

    def _make_nonce(self, counter: int) -> bytes:
        # 12-byte nonce: 4 bytes fixed prefix + 8 bytes big-endian monotonic counter
        return struct.pack(">IQ", 0xA5A5A5A5, counter)

    def pack_frame(self, plaintext: bytes) -> bytes:
        nonce = self._make_nonce(self.send_nonce_seq)
        self.send_nonce_seq += 1
        ciphertext = self.cipher.encrypt(nonce, plaintext, None)
        # Length-prefixed frame: [Length (4B)] || [Ciphertext + Tag (16B)]
        return struct.pack(">I", len(ciphertext)) + ciphertext

    def unpack_frame(self, ciphertext: bytes) -> bytes:
        nonce = self._make_nonce(self.recv_nonce_seq)
        self.recv_nonce_seq += 1
        return self.cipher.decrypt(nonce, ciphertext, None)
```

### 4.1 Connection Invariants
- **Replay Protection:** Nonce must be derived strictly from a monotonically increasing frame counter. Any frame arriving with an out-of-order or duplicate sequence index is rejected immediately.
- **Exponential Reconnection Backoff:** In client-side agents: `delay = min(base_delay * (2 ** retry_count) + random_jitter, max_delay)`. Cap maximum delay at 15 seconds.
