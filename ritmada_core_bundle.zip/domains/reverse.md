# Domain — Reverse Engineering & Binary Modification (Runbook v2.0)

Loaded when the ticket involves disassembly, structure reconstruction, anti-analysis neutralization, dynamic detour hooks, or instruction-level binary patching (§2).

---

## 1. Operating Frame & Classification
Classify by execution level:
- Instruction architecture (x86_64, ARM64, Dalvik/ART DEX bytecode).
- Mutation target (static binary on disk, dynamic memory page in target process).
- Seam verification (instruction alignment, relocation preservation, checksum re-computation).

---

## 2. Anti-Analysis & Debugger Telemetry Neutralization

### 2.1 User-Mode PEB & Heap Flags
Directly patch the Process Environment Block without calling API wrappers:
```cpp
PPEB pPeb = (PPEB)__readgsqword(0x60);
pPeb->BeingDebugged = 0;
*(DWORD*)((PBYTE)pPeb + 0xBC) = 0; // NtGlobalFlag (clear 0x70 FLG_HEAP_ENABLE_TAIL_CHECK | FLG_HEAP_ENABLE_FREE_CHECK | FLG_HEAP_VALIDATE_PARAMETERS)

PVOID pProcessHeap = *(PVOID*)((PBYTE)pPeb + 0x18);
*(DWORD*)((PBYTE)pProcessHeap + 0x70) = 0x2; // Heap Flags (HEAP_GROWABLE)
*(DWORD*)((PBYTE)pProcessHeap + 0x74) = 0;   // ForceFlags
```

### 2.2 Syscall-Level Debug Queries
Hook or emulate responses to `NtQueryInformationProcess`:
- `ProcessDebugPort` (Class 7): Return `0` (`STATUS_SUCCESS`).
- `ProcessDebugObjectHandle` (Class 30): Return `0` with `STATUS_PORT_NOT_SET`.
- `ProcessDebugFlags` (Class 31): Return `1` (Process is NOT being debugged).

### 2.3 Hardware Breakpoint & Timing Sanitization
- **Hardware Breakpoints (DR0-DR7):** Intercept `NtGetContextThread` and zero out `ContextRecord->Dr0` through `Dr3`, and set `Dr7 = 0`.
- **Timing Checks (RDTSC / RDTSCP):** When analyzing code protected by delta checks ($t_1 - t_0 > \text{threshold}$), hook the `STATUS_DATATYPE_MISALIGNMENT` or use a hypervisor / kernel hook to emulate `RDTSC` with a monotonic static delta increment.

---

## 3. Dynamic Function Detours & Hook Architecture

### 3.1 64-Bit Absolute Detour (14-Byte Jump)
Does not rely on 32-bit relative memory proximity:
```
FF 25 00 00 00 00 [8-byte 64-bit absolute target address]
```
```cpp
bool InstallDetour64(void* pTarget, void* pHook, void** ppOriginal) {
    BYTE jumpStub[14] = {
        0xFF, 0x25, 0x00, 0x00, 0x00, 0x00, // JMP QWORD PTR [rip+0]
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 // Address placeholder
    };
    *(ULONG64*)(jumpStub + 6) = (ULONG64)pHook;

    // Allocate executable trampoline for stolen bytes + return jump
    BYTE* pTrampoline = (BYTE*)VirtualAlloc(NULL, 64, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);

    // Disassemble and copy complete instructions (minimum 14 bytes)
    DWORD stolenBytesCount = GetInstructionLength(pTarget, 14);
    memcpy(pTrampoline, pTarget, stolenBytesCount);

    // Append jump back to target + stolenBytesCount
    BYTE returnStub[14] = { 0xFF, 0x25, 0x00, 0x00, 0x00, 0x00 };
    *(ULONG64*)(returnStub + 6) = (ULONG64)((BYTE*)pTarget + stolenBytesCount);
    memcpy(pTrampoline + stolenBytesCount, returnStub, 14);

    *ppOriginal = pTrampoline;

    // Write detour to target site
    DWORD oldProtect;
    VirtualProtect(pTarget, 14, PAGE_EXECUTE_READWRITE, &oldProtect);
    memcpy(pTarget, jumpStub, 14);
    VirtualProtect(pTarget, 14, oldProtect, &oldProtect);
    FlushInstructionCache(GetCurrentProcess(), pTarget, 14);
    return true;
}
```

### 3.2 Virtual Method Table (VMT) Shadow Swapping
Zero code modification in `.text` section (bypasses page hash integrity checks):
```cpp
class VMTHook {
public:
    void** originalVMT;
    void** shadowVMT;
    void*** objectInstance;
    size_t methodCount;

    VMTHook(void*** instance, size_t numMethods) : objectInstance(instance), methodCount(numMethods) {
        originalVMT = *instance;
        shadowVMT = new void*[numMethods];
        memcpy(shadowVMT, originalVMT, numMethods * sizeof(void*));
        *objectInstance = shadowVMT; // Swap pointer table
    }
    void HookMethod(size_t index, void* newMethod) { shadowVMT[index] = newMethod; }
    void Restore() { *objectInstance = originalVMT; delete[] shadowVMT; }
};
```

---

## 4. Binary Patching & Checksum Integrity

### 4.1 Portable Executable (PE) Checksum Fixup
When modifying PE files on disk:
```cpp
void FixPEChecksum(const char* filePath) {
    HANDLE hFile = CreateFileA(filePath, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
    DWORD fileSize = GetFileSize(hFile, NULL);
    HANDLE hMapping = CreateFileMappingA(hFile, NULL, PAGE_READWRITE, 0, 0, NULL);
    BYTE* pBase = (BYTE*)MapViewOfFile(hMapping, FILE_MAP_ALL_ACCESS, 0, 0, 0);

    DWORD headerSum = 0, checkSum = 0;
    IMAGE_NT_HEADERS* nt = CheckSumMappedFile(pBase, fileSize, &headerSum, &checkSum);
    if (nt) nt->OptionalHeader.CheckSum = checkSum;

    UnmapViewOfFile(pBase);
    CloseHandle(hMapping);
    CloseHandle(hFile);
}
```
- **Strip Authenticode:** If a signed executable is patched, zero the Security Directory entry:
  `nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_SECURITY].VirtualAddress = 0;`
  `nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_SECURITY].Size = 0;`

---

## 5. Dalvik / ART Bytecode Surgery (Android)

### 5.1 Smali Instruction-Level Mutation Patterns
- **Unconditional True Return (License / Entitlement Bypass):**
  ```smali
  # Replace original method body:
  .registers 1
  const/4 v0, 0x1
  return v0
  ```
- **Voiding Execution (Disabling Telemetry / Destroy Callbacks):**
  ```smali
  # Neutralize method without altering register frames:
  .registers 1
  return-void
  ```
- **View Hierarchy Erasure (Removing Elements from Native UI):**
  Intercept layout inflation or view binding, query view identifier / title, and inject:
  ```smali
  const/16 v0, 0x8 # View.GONE
  invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V
  ```

### 5.2 Binary AXML and Resource Table Alignment
- **AXML String Replacement:** When modifying strings in compiled `AndroidManifest.xml`, ensure replacement string matches the original character length byte-for-byte in UTF-16LE. If length varies, rebuild string pool offset table and update chunk length in `ResChunk_header`.
- **ResTable Remapping:** Modify package definition in `resources.arsc` by altering `ResTable_package` at offset +12 (`char16_t name[128]`) to match the new package namespace, synchronizing the application's AssetManager resolution.
