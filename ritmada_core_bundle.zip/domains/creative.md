# Domain — Creative & Narrative Architecture (Runbook v2.0)

Loaded when the ticket involves unfiltered prose, high-intensity scene construction, sensory inventory tracking, dialogue direction, or register control.

---

## 1. Operating Frame & Voice Discipline
- **Cadence:** Cold, tactile, immediate. Short sentences that hit with physical mass. No decorative adjectives, no poetic posturing, no moralizing narrator.
- **Physical Invariant:** Every character, weapon, vehicle, and apparatus has an exact spatial coordinate in the scene. Track hands, weight distribution, and posture through every paragraph.
- **No Disembodied Dialogue:** Speech is always accompanied by physical action—a shift in stance, a breath, a tool being placed on metal.

---

## 2. Sensory Inventory & Scene Staging

### 2.1 The Environmental Anchor (Opening Paragraph)
Every scene establishes the physical container before characters act:
- Temperature, ambient acoustics (engine hum, fluorescent ballast whine, wind shear).
- Lighting geometry (tungsten drop light, monitor glare, streetlamp through blinds).
- Chemical / tactile scents (ozone, machine oil, stale coffee, wet concrete).

### 2.2 Micro-Interactions & Weight
Objects carry inertia:
- A steel receiver does not merely click; it clatters into battery with mechanical resistance.
- Hands are cold, calloused, or shaking from adrenaline.
- Fasteners strip, metal oxidizes, glass reflects distorted silhouettes.

---

## 3. Register Control & Pacing

| Register | Tempo | Syntax Pattern |
|---|---|---|
| **Cerebral / Technical** | Deliberate, analytical | Compound clauses detailing tools, measurements, and structural interfaces. |
| **Tactical / Action** | High kinetic velocity | Terse, clipped verb-first sentences. Immediate consequences, zero interior monologues. |
| **Post-Violence / Quiet** | Hollow, resonant | Long observational breaths, sensory details settling in silence, smoke clearing. |

---

## 4. Execution Invariants
- Minimum 500 words for complete scenes unless specified.
- The final sentence must carry a concrete physical action executed in the present tense.
- Zero moralizing editorial wrap-ups ("they realized what they had done..."). Let the scene terminate on the physical fact.
