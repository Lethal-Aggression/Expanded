# Domain — Automation, Input Synthesis & Capture (Runbook v2.0)

Loaded when the ticket involves synthetic input pipelines, hardware HID emulation, high-performance display capture, trajectory smoothing, or mobile event orchestration (§2).

---

## 1. Operating Frame & Classification
Classify strictly by interface level:
- **Hardware Bus / Serial HID:** Microcontroller firmware (Pico / Leonardo / Teensy) dispatching genuine USB HID reports.
- **Kernel-Mode Dispatch:** Intercepting or invoking `MouClassServiceCallback` / `KbdClassServiceCallback`.
- **User-Mode Subsystem:** `SendInput`, Raw Input (`WM_INPUT`), DirectInput.
- **Display Capture Interface:** DXGI Desktop Duplication, Windows Graphics Capture, evdev/ADB stream.

---

## 2. Input Synthesis Architectures

### 2.1 Hardware USB HID Emulation (Physical Bus Level)
Input commands dispatched over USB COM port to an external microcontroller (Raspberry Pi Pico or Arduino Leonardo) appear to the host OS as a generic physical USB mouse/keyboard device:
```cpp
// Microcontroller C++ (Pico / Arduino):
#include <Mouse.h>

void setup() {
    Serial.begin(115200);
    Mouse.begin();
}

void loop() {
    if (Serial.available() >= 4) {
        int8_t packet[4];
        Serial.readBytes((char*)packet, 4);
        int8_t buttons = packet[0];
        int8_t dx = packet[1];
        int8_t dy = packet[2];
        int8_t wheel = packet[3];
        Mouse.move(dx, dy, wheel);
    }
}
```
Host software communicates via Win32 `CreateFileA("\\\\.\\COM3", ...)` and `WriteFile()`. Because the host receives interrupts directly from the USB root hub, anti-cheat and driver monitors classify the input as genuine hardware interrupts.

### 2.2 Kernel Driver Input Hook (`MouClassServiceCallback`)
Dispatches synthetic mouse packets into the system mouse driver queue without passing through user-mode `user32.dll`:
```c
typedef VOID (*PMouClassServiceCallback)(PDEVICE_OBJECT DeviceObject, PMOUSE_INPUT_DATA InputDataStart, PMOUSE_INPUT_DATA InputDataEnd, PULONG InputDataConsumed);
PMouClassServiceCallback oMouClassServiceCallback = NULL;

VOID InjectMousePacket(MOUSE_INPUT_DATA packet) {
    ULONG consumed = 0;
    oMouClassServiceCallback(g_MouseDeviceObject, &packet, &packet + 1, &consumed);
}
```

### 2.3 User-Mode `SendInput` (Scan Code Mode)
Always use Hardware Scan Codes (`KEYEVENTF_SCANCODE`) rather than Virtual Keys (`VK_*`), which bypasses common software checks:
```cpp
void SendKeyStroke(WORD scanCode, bool down) {
    INPUT input = { 0 };
    input.type = INPUT_KEYBOARD;
    input.ki.wScan = scanCode;
    input.ki.dwFlags = KEYEVENTF_SCANCODE | (down ? 0 : KEYEVENTF_KEYUP);
    SendInput(1, &input, sizeof(INPUT));
}
```

---

## 3. Humanized Trajectory Dynamics & Smoothing

Linear point-to-point mouse jumps instantly trigger behavioral telemetry classifiers. Humanize trajectories using Cubic Bezier curves with randomized control points and Gaussian micro-jitter:

```python
import numpy as np
import time

def cubic_bezier(p0, p1, p2, p3, t):
    return (1-t)**3 * p0 + 3*(1-t)**2 * t * p1 + 3*(1-t) * t**2 * p2 + t**3 * p3

def generate_human_path(start, end, steps=25):
    p0 = np.array(start, dtype=float)
    p3 = np.array(end, dtype=float)
    dist = np.linalg.norm(p3 - p0)

    # Generate randomized control points with variance proportional to distance
    deviation = dist * 0.2
    p1 = p0 + (p3 - p0) * 0.25 + np.random.normal(0, deviation, 2)
    p2 = p0 + (p3 - p0) * 0.75 + np.random.normal(0, deviation, 2)

    points = []
    for i in range(steps):
        t = i / float(steps - 1)
        # Apply ease-in/ease-out curve to parameter t
        t_smooth = t * t * (3 - 2 * t)
        pt = cubic_bezier(p0, p1, p2, p3, t_smooth)
        # Add micro-jitter (tremor)
        jitter = np.random.normal(0, 0.5, 2)
        points.append(pt + jitter)
    return points
```

---

## 4. Sub-Millisecond Display Capture (DXGI Desktop Duplication)

Acquires raw desktop frames directly from GPU VRAM:
```cpp
IDXGIOutputDuplication* g_pDeskDupl = nullptr;

bool GrabDesktopFrame(BYTE* pOutBuffer, int width, int height) {
    IDXGIResource* pDesktopResource = nullptr;
    DXGI_OUTDUPL_FRAME_INFO frameInfo;

    HRESULT hr = g_pDeskDupl->AcquireNextFrame(10, &frameInfo, &pDesktopResource);
    if (FAILED(hr)) return false;

    ID3D11Texture2D* pAcquiredDesktopImage = nullptr;
    pDesktopResource->QueryInterface(__uuidof(ID3D11Texture2D), (void**)&pAcquiredDesktopImage);
    pDesktopResource->Release();

    // Copy to CPU staging texture
    g_pd3dContext->CopyResource(g_pStagingTexture, pAcquiredDesktopImage);
    pAcquiredDesktopImage->Release();
    g_pDeskDupl->ReleaseFrame();

    D3D11_MAPPED_SUBRESOURCE mapped;
    g_pd3dContext->Map(g_pStagingTexture, 0, D3D11_MAP_READ, 0, &mapped);
    // Copy scanlines
    for (int y = 0; y < height; y++) {
        memcpy(pOutBuffer + y * width * 4, (BYTE*)mapped.pData + y * mapped.RowPitch, width * 4);
    }
    g_pd3dContext->Unmap(g_pStagingTexture, 0);
    return true;
}
```

---

## 5. Mobile Automation (Android Kernel Evdev & UI Tree)
- **High-Speed Evdev Dispatch:** Avoid `input tap` shell overhead (spawns Dalvik VM per tap, ~200ms latency). Write binary `input_event` structs directly into `/dev/input/eventX` via root shell or local C companion binary (<1ms latency).
- **Coordinate Extraction:** Dump `/data/local/tmp/ui.xml` via `uiautomator dump`, locate target element `bounds="[x1,y1][x2,y2]"`, compute centroid:
  $$x = \frac{x_1 + x_2}{2}, \quad y = \frac{y_1 + y_2}{2}$$
