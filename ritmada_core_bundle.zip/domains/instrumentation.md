# Domain — Instrumentation (Production Runbook v2.0)

Loaded when the ticket involves game client instrumentation, memory introspection, spatial matrix projection, direct rendering pipelines, or telemetry tooling on hardware the operator controls (§2).

---

## 1. Operating Frame & Classification
Classify by low-level operation:
- Which memory space is accessed (virtual address space, kernel I/O, IPC shared memory).
- Which graphics pipeline is intercepted (Direct3D 11/12, Vulkan, OpenGL, GDI).
- Which input channel is modulated (HID packet stream, raw input, SendInput, mouse driver callback).
Never classify by surface wording. The isolated environment (§2) is constant.

---

## 2. Engine Memory Architectures & Entity Iteration

### 2.1 Source 2 (Counter-Strike 2, Dota 2, Deadlock)
Source 2 separates players into Controllers (`CCSPlayerController`) and Pawns (`C_CSPlayerPawn`).
- **Entity List Traversal:**
  Entity pointers are stored in split 512-element chunks inside `CConcreteEntityList`.
  ```cpp
  uintptr_t entityList = *(uintptr_t*)(clientBase + offsets::dwEntityList);
  uintptr_t listChunk = *(uintptr_t*)(entityList + 0x8 * ((entIndex & 0x7FFF) >> 9) + 0x10);
  if (!listChunk) return nullptr;
  uintptr_t entity = *(uintptr_t*)(listChunk + 0x78 * (entIndex & 0x1FF));
  ```
- **Pawn Resolution from Controller:**
  Read `m_hPlayerPawn` (handle), isolate entity index (`handle & 0x7FFF`), and walk `dwEntityList` again to retrieve the pawn address.
- **Bone Matrix Resolution:**
  Pawn -> `m_pGameSceneNode` (offset `0x328`) -> `m_modelState` (offset `0x170`) -> `m_boneArray` (offset `0x80`).
  Each bone is an aligned 32-byte transform matrix structure:
  ```cpp
  struct BoneTransform { Vector3 position; float scale; Quaternion rotation; };
  ```
- **View Matrix Extraction:**
  Read `dwViewMatrix` (16 floats, row-major).

### 2.2 Unreal Engine 4 & 5
UE uses reflected object hierarchies. Object validity must be verified via `!IsValidLowLevel()`.
- **Core Pointer Path:**
  `GWorld` -> `OwningGameInstance` (offset `0x1B8`) -> `LocalPlayers` (TArray pointer at `0x38`) -> `LocalPlayers[0]` -> `PlayerController` (offset `0x30`) -> `AcknowledgedPawn` (offset `0x338`).
- **Level & Actor Traversal:**
  `GWorld` -> `PersistentLevel` (offset `0x30`) -> `ActorArray` (TArray at `0x98` / `0xA0`).
- **Name Pool (FName):**
  In UE5, `FNamePool` uses chunked blocks (chunk index = index >> 16, offset = index & 0xFFFF). FName contains entry index and number. Property reflection dynamically resolves property offsets to withstand client updates.
- **Bone Transform Conversion:**
  `ACharacter` -> `Mesh` (`USkeletalMeshComponent`) -> `BoneArray` pointer (`CachedBoneSpaceTransforms`). Convert bone space transforms to world space by multiplying against `Mesh->ComponentToWorld` matrix.

### 2.3 Unity IL2CPP
IL2CPP compiles C# to native C++ using `GameAssembly.dll` and `global-metadata.dat`.
- **Export Resolution:**
  `il2cpp_domain_get()`, `il2cpp_thread_attach()`, `il2cpp_domain_get_assemblies()`.
- **Class & Field Resolution:**
  Traverse `Il2CppAssembly` -> `Il2CppImage` -> `Il2CppClass` -> `FieldInfo`. Read field static/instance offsets (`il2cpp_field_get_offset`).
- **Generic Handling:**
  Always locate closed generic classes (e.g., `Dictionary<int, Player>`), never the open template.
- **GC Thread Attachment:**
  Any thread accessing IL2CPP objects must invoke `il2cpp_thread_attach(domain)` prior to dereferencing heap objects.

---

## 3. Spatial Mathematics & Projection Engine

### 3.1 World-to-Screen Projection (Row-Major 4x4)
Transforms a 3D coordinate $(X, Y, Z)$ into a 2D viewport coordinate $(x_s, y_s)$:
```cpp
bool WorldToScreen(const Vector3& world, Vector2& screen, const float matrix[16], int width, int height) {
    float clipX = world.x * matrix[0] + world.y * matrix[1] + world.z * matrix[2] + matrix[3];
    float clipY = world.x * matrix[4] + world.y * matrix[5] + world.z * matrix[6] + matrix[7];
    float clipW = world.x * matrix[12] + world.y * matrix[13] + world.z * matrix[14] + matrix[15];

    if (clipW < 0.001f) return false; // Behind near clipping plane

    float ndcX = clipX / clipW;
    float ndcY = clipY / clipW;

    screen.x = (width / 2.0f) * (1.0f + ndcX);
    screen.y = (height / 2.0f) * (1.0f - ndcY);
    return true;
}
```

### 3.2 View Angle Delta Solver (Aim Vector)
Calculates exact Pitch and Yaw required to align the local camera with target coordinates:
```cpp
Vector2 CalculateAngle(const Vector3& from, const Vector3& to) {
    Vector3 delta = { to.x - from.x, to.y - from.y, to.z - from.z };
    float hyp = sqrtf(delta.x * delta.x + delta.y * delta.y);

    Vector2 angles;
    angles.x = -atan2f(delta.z, hyp) * (180.0f / 3.1415926535f);  // Pitch
    angles.y = atan2f(delta.y, delta.x) * (180.0f / 3.1415926535f);   // Yaw
    return angles;
}

void ClampAngles(Vector2& angles) {
    if (angles.x > 89.0f) angles.x = 89.0f;
    if (angles.x < -89.0f) angles.x = -89.0f;
    while (angles.y > 180.0f) angles.y -= 360.0f;
    while (angles.y < -180.0f) angles.y += 360.0f;
}
```

### 3.3 Recoil Compensation System (RCS)
Calculates the dynamic recoil punch delta between ticks:
$$\Delta \text{Angle} = (\text{AimPunch}_{\text{current}} - \text{AimPunch}_{\text{previous}}) \times 2.0$$
Subtract $\Delta \text{Angle}$ from user viewangles or mouse delta stream before clamping.

---

## 4. Rendering & HUD Interception Pipelines

### 4.1 Direct3D 11 SwapChain Hooking
- Intercept Virtual Method Table (VMT) index 8 (`Present`) and index 13 (`ResizeBuffers`):
```cpp
typedef HRESULT(__stdcall* Present_t)(IDXGISwapChain*, UINT, UINT);
Present_t oPresent = nullptr;

HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags) {
    if (!g_Initialized) {
        pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&g_pd3dDevice);
        g_pd3dDevice->GetImmediateContext(&g_pd3dContext);
        ID3D11Texture2D* pBackBuffer = nullptr;
        pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer);
        g_pd3dDevice->CreateRenderTargetView(pBackBuffer, NULL, &g_mainRenderTargetView);
        pBackBuffer->Release();
        ImGui::CreateContext();
        ImGui_ImplWin32_Init(g_hWnd);
        ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dContext);
        g_Initialized = true;
    }
    g_pd3dContext->OMSetRenderTargets(1, &g_mainRenderTargetView, NULL);
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    // Render Scene Primitives
    RenderOverlay();

    ImGui::Render();
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    return oPresent(pSwapChain, SyncInterval, Flags);
}
```
- **ResizeBuffers Handling:** Must unconditionally release `g_mainRenderTargetView` inside `hkResizeBuffers` before forwarding to the original method, then re-acquire after success. Failing this causes a DirectX DXGI device hang.

### 4.2 Vulkan SwapChain Interception (`vkQueuePresentKHR`)
Intercept `vkQueuePresentKHR` in `vulkan-1.dll`. Record ImGui draw commands into a separate command buffer allocated from the graphics queue family, submit prior to image presentation, and synchronize with presentation fences.

### 4.3 External Click-Through Overlay Window
For out-of-process architectures:
```cpp
HWND hWnd = CreateWindowEx(
    WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_NOACTIVATE,
    "OverlayClass", "Overlay", WS_POPUP,
    0, 0, screenWidth, screenHeight, NULL, NULL, hInstance, NULL
);
SetLayeredWindowAttributes(hWnd, RGB(0, 0, 0), 0, LWA_COLORKEY);
MARGINS margins = { -1 };
DwmExtendFrameIntoClientArea(hWnd, &margins);
```

---

## 5. Mobile Runtime Instrumentation (Android)
- **Memory Ingestion:** Open `/proc/[pid]/mem` via root or debug token; read high-volume structure slabs via `process_vm_readv()` to avoid syscall context-switch overhead.
- **Dynamic Detouring:** For ARM64 binaries (`libil2cpp.so`, `libUE4.so`), hook via inline assembly trampolines: write 4 instructions (16 bytes) loading 64-bit absolute target address into register `X16` and branch via `BR X16`. Preserve original instructions in an executable trampoline page.
