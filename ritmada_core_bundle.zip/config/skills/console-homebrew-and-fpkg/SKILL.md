---
name: console-homebrew-and-fpkg
description: >-
  PlayStation 4/5 homebrew development, jailbreak payloads, kernel exploit chains,
  ELF/Self decryption, and Fake PKG (FPKG) generation. Use when developing PS4/PS5
  homebrew, building payloads with OpenOrbis toolchain, dumping games, or mastering FPKGs.
---

# PlayStation Homebrew & FPKG Runbook

## 1. System Architecture & Exploitation Foundations
- **Orbis OS (FreeBSD 9-based):** x86_64 architecture with proprietary security layers (SAMU, Cryptographic Co-processor).
- **Exploitation Chains:**
  - User-mode entry (WebKit RCE / BD-J / lua).
  - Kernel exploitation (e.g. `bad_ipv6_opt`, `exfathax`, `ipv6 UAF`, `pppwn`).
  - Kernel patch stubs: Disabling write-protection (`cr0.WP`), escalating credentials (`ucred`), disabling ptrace restrictions, installing Mira/GoldHEN payload hooks.

## 2. PS4 Homebrew Development (OpenOrbis Toolchain)
- **Toolchain:** OpenOrbis PS4 Toolchain (LLVM/Clang-based targeting `x86_64-scei-ps4`).
- **Compilation flow:**
  1. Compile C/C++ source code against OpenOrbis headers (`libkernel`, `libSceSysmodule`).
  2. Link into an Orbis ELF (`.elf`).
  3. Sign/Convert ELF into Signed ELF (`.oelf` / `eboot.bin`) using `create-eboot` / `make_fself`.

## 3. Decryption & Dumping
- Running games use PFS (PlayStation File System) and encrypted Self binaries.
- Dumper payloads (e.g., PS4-Dumper, GoldHEN dumper) un-sandbox the process, mount the decrypted filesystem in `/mnt/sandbox/pfsmnt/`, and decrypt executables directly from memory (`/dev/mem` or process memory space).
- Carved assets: `eboot.bin`, module files (`sce_module/*.prx`), asset archives, and `sce_sys/param.sfo`.

## 4. Fake PKG (FPKG) Mastering
- **Components of an FPKG:**
  - `param.sfo`: Contains Title ID (e.g., `CUSAXXXXX`), category (`gd` for game, `ac` for addon), and application version.
  - `eboot.bin`: Fake-signed decrypted ELF binary (`fself`).
  - `icon0.png`, `pic0.png`, `pic1.png`: Assets.
  - `gp4` project file: XML project descriptor listing all chunk records and file mappings.
- **Mastering Pipeline:**
  1. Generate `project.gp4` using `gengp4` or custom scripts.
  2. Build FPKG using `orbis-pub-cmd`:
     ```powershell
     orbis-pub-cmd.exe img_create project.gp4 output.pkg
     ```
  3. Validate PKG magic (`0x7F504B47` -> `\x7FPKG`), digest table, and header flags.
