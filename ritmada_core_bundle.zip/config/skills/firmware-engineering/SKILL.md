---
name: firmware-engineering
description: >-
  Firmware extraction, analysis, reverse engineering, emulation, and modification.
  Use when the user wants to dump, carve, unpack, decompile, patch, or analyze embedded
  device firmware (routers, IoT, basebands, UEFI, bootloaders, microcontrollers).
---

# Firmware Engineering Runbook

## 1. Extraction and Unpacking
- **Carving & Inspection:**
  - `binwalk -e -M <firmware.bin>` (recursive entropy analysis and file carving)
  - Inspect entropy charts: `binwalk -E <firmware.bin>` to spot encrypted/compressed regions.
  - Carve raw filesystems: SquashFS (`unsquashfs`), JFFS2 (`jefferson`), YAFFS2 (`unyaffs`), UBI (`ubireader_extract_images`).
- **Raw Memory & Flash Dumps:**
  - SPI Flash / EEPROM dumps via programmer tools (`flashrom -p <programmer> -r dump.bin`).
  - Parsing partition tables: MBR, GPT, U-Boot header (`dumpimage -l`), device trees (`dtc -I dtb -O dts`).

## 2. Bootloader & Kernel Analysis
- **U-Boot:**
  - Extract kernel/ramdisk from legacy uImage: `dumpimage -T firmware -p 0 -o kernel.raw <uImage>`.
  - Extract FDT (Flattened Device Tree) and inspect memory maps and bootargs.
- **UEFI:**
  - Inspect volumes via `UEFITool` and extract PE32/TE images.
  - Analyze DXE drivers, SEC core, and PEI modules in Ghidra / IDA Pro.

## 3. Disassembly & Architecture Resolution
- Identify target architecture (`file`, `readelf`, or byte pattern inspection: ARM, MIPS, RISC-V, Xtensa, AVR, PowerPC).
- Load into Ghidra / IDA Pro / Binary Ninja:
  - If bare-metal, determine Base Load Address and Vector Table offsets before disassembly.
  - Resolve strings, function prologues, and memory-mapped I/O (MMIO) registers from datasheet.

## 4. Emulation & Dynamic Execution
- **System Emulation:** `qemu-system-<arch>` with carved kernel and device tree.
- **User-space Emulation:** `qemu-<arch>-static -L <rootfs_path> <binary>` or `chroot`.
- **Full Automation:** Firmadyne / FirmAE / Qiling framework for dynamic execution and service hook inspection.

## 5. Patching and Repacking
- Modify target binaries/scripts in the carved filesystem root.
- Rebuild filesystem: `mksquashfs <dir> <output.squashfs> -comp xz` (match original endianness and block size).
- Re-calculate CRC32/SHA256 headers in U-Boot or vendor-specific wrappers before flashing.
