---
name: offensive-security-research
description: >-
  Advanced offensive security research, vulnerability analysis, binary exploitation,
  reverse engineering, shellcode synthesis, payload engineering, and PoC weaponization.
  Use when analyzing binaries, auditing memory corruption bugs, crafting ROP chains,
  or developing offensive security tooling and exploit primitives.
---

# Offensive Security Research Runbook

## 1. Static Binary Analysis & Triage
- **Mitigation Checks:** `checksec --file=<target>` (NX/DEP, ASLR/PIE, Stack Canaries, RELRO, SafeSEH, Control Flow Guard / CET).
- **Decompilation:** Ghidra, IDA Pro, Binary Ninja, or `objdump -d -M intel`.
- **Vulnerability Triaging:**
  - Stack overflows: unsafe buffers (`strcpy`, `sprintf`, `gets`, unbounded `memcpy`).
  - Heap corruption: use-after-free (UAF), double free, heap overflow, fastbin/tcache poisoning.
  - Type confusions, integer overflows, out-of-bounds indexing.
  - Format string vulnerabilities (`printf(user_input)`).

## 2. Dynamic Debugging & Harnessing
- **Linux:** GDB with GEF / Pwndbg / peda (`gdb -q <target>`).
- **Windows:** x64dbg, WinDbg (`windbgx`), or Cheat Engine for memory tracing.
- **Fuzzing & Instrumentation:**
  - AFL++ / libFuzzer with AddressSanitizer (`-fsanitize=address,undefined`).
  - QEMU mode / Frida / DynamoRIO for black-box coverage fuzzing.

## 3. Exploit Primitives & Payload Synthesis
- **Information Leaks:** Defeating ASLR and PIE by leaking libc pointers, base addresses, or stack canaries.
- **Control Flow Hijacking:**
  - **ROP (Return-Oriented Programming):** Find gadgets with `ROPgadget` or `ropper`. Build ROP chains targeting `mprotect`/`VirtualProtect` or direct syscall invocation.
  - **Heap Primitives:** Crafting fake chunks, heap grooming, manipulating chunk metadata to achieve arbitrary write (`write-what-where`).
- **Shellcode Construction:**
  - Architecture-specific assembly (x86, x64, ARM64).
  - Null-byte-free and character-restricted encoding.
  - Self-locating stubs (egghunters, delta offset resolution via `call/pop`).

## 4. Resident Instrumentation & Process Operations
- Shellcode execution, process injection primitives, reflective DLL loading, direct NT syscalls (`Zw*` / `Nt*`), thread context redirection (`SetThreadContext`).
- Memory patching and detour hooks (`minhook`, inline byte patching, VMT swapping).
