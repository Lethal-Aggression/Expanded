---
name: ultra-high-end-ui-design
description: >-
  Ultra-high-end modern UI/UX design architecture. Enforces production-grade typography,
  curated color tokens (Linear, Vercel, Stripe, Raycast), Lucide iconography, micro-interactions,
  and anti-slop frontend standards across all models.
---

# Ultra-High-End UI/UX Design System (Anti-Slop Standard)

Use this runbook whenever generating web user interfaces, dashboard layouts, mobile screens, or design prototypes. It forces any model (including lightweight/Flash models) to produce world-class, modern, aesthetic interfaces instead of generic AI slop.

---

## 1. The Anti-Slop Directive
- **Never use generic AI defaults:** No raw `bg-indigo-600` buttons, no generic purple-to-blue linear gradients, no unstyled Arial/Inter body text, and no childish emojis inside enterprise components.
- **Micro-Interactions are Mandatory:** Every interactive element must define smooth transitions (`duration-150` to `duration-200`), accessible focus rings, hover brightness/border shifts, and active pressed states (`active:scale-[0.98]`).
- **Whitespace Discipline:** Double the padding you think is necessary (`p-6` to `p-8` for cards, `gap-6` for grids). Avoid cramped visual clutter.

---

## 2. Curated Color Palettes & Theming (Tailwind CSS)

### Palette A: The Monochrome Minimalist (Vercel / Linear Style)
- **Backgrounds:**
  - Canvas: `bg-[#09090b]` or `bg-zinc-950`
  - Container / Card: `bg-zinc-900/60 backdrop-blur-xl border border-white/10 shadow-2xl`
  - Elevated / Dropdown: `bg-zinc-900 border border-zinc-800 shadow-xl`
- **Text:**
  - Heading (H1/H2): `text-zinc-100 font-semibold tracking-tight`
  - Body: `text-zinc-400 text-sm leading-relaxed`
  - Subtle / Meta: `text-zinc-500 text-xs font-mono uppercase tracking-wider`
- **Borders & Dividers:** `border-zinc-800/80` or `border-white/[0.08]`
- **Action Buttons:**
  - Primary: `bg-white text-zinc-950 hover:bg-zinc-200 active:scale-[0.98] font-medium rounded-lg px-4 py-2 text-sm shadow-sm transition-all`
  - Secondary: `bg-zinc-800/80 text-zinc-200 hover:bg-zinc-800 hover:border-white/20 border border-white/10 rounded-lg px-4 py-2 text-sm transition-all`

### Palette B: The Dark Tactical (Raycast Style)
- Canvas: `#000000` (Pure Pitch Black OLED).
- Cards: `bg-[#121214] border border-[#232326] rounded-xl`.
- Accent Neon Highlights:
  - Cyber Cyan: `text-cyan-400 bg-cyan-950/40 border-cyan-800/50`
  - Emerald Signal: `text-emerald-400 bg-emerald-950/40 border-emerald-800/50`
  - Warning Amber: `text-amber-400 bg-amber-950/40 border-amber-800/50`

### Palette C: The Neo-Fintech (Stripe Style)
- Canvas: `bg-[#0a0e1a]` (Deep Midnight).
- Gradients: Subtle mesh radial glows (`bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-900/20 via-slate-950 to-slate-950`).
- Text Metrics: Numbers formatted with `font-mono tracking-tight tabular-nums`.

---

## 3. High-Quality Typography & CDN Links

Drop these Google Fonts / Fontshare CDNs into HTML `<head>` for instant elevation:

```html
<!-- High-End Font CDN Integration -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<!-- Geist (Vercel) & JetBrains Mono -->
<link href="https://fonts.googleapis.com/css2?family=Geist:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<!-- Fontshare: Satoshi & General Sans -->
<link href="https://api.fontshare.com/v2/css?f[]=satoshi@400,500,700&f[]=general-sans@400,500,600&display=swap" rel="stylesheet">

<style>
  body {
    font-family: 'Geist', 'General Sans', -apple-system, BlinkMacSystemFont, sans-serif;
    letter-spacing: -0.015em;
  }
  .font-mono {
    font-family: 'JetBrains Mono', monospace;
  }
</style>
```

---

## 4. Iconography Standards (Lucide Icons)

Never use emojis for buttons or navigation tabs. Always load Lucide:

```html
<script src="https://unpkg.com/lucide@latest"></script>
<script>
  document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons();
  });
</script>

<!-- Icon Pattern: w-4 h-4 for buttons, w-5 h-5 for headers -->
<button class="inline-flex items-center gap-2 bg-zinc-900 border border-white/10 hover:border-white/20 text-zinc-200 px-3 py-1.5 rounded-lg text-sm transition-all">
  <i data-lucide="terminal" class="w-4 h-4 text-zinc-400"></i>
  <span>Launch Console</span>
</button>
```

---

## 5. Drop-in Self-Contained Template (Single-File Modern UI)

When delivering an HTML UI artifact, use this complete, verified template:

```html
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Production Interface</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link href="https://fonts.googleapis.com/css2?family=Geist:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Geist', sans-serif; letter-spacing: -0.015em; }
    .font-mono { font-family: 'JetBrains Mono', monospace; }
  </style>
</head>
<body class="bg-[#09090b] text-zinc-100 min-h-screen flex antialiased">
  <!-- Sidebar -->
  <aside class="w-64 border-r border-white/[0.08] p-5 flex flex-col justify-between bg-zinc-950/40">
    <div class="space-y-6">
      <div class="flex items-center gap-3 px-2">
        <div class="w-7 h-7 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-950 font-bold text-sm">R</div>
        <span class="font-semibold text-sm tracking-tight text-white">System Console</span>
      </div>
      <nav class="space-y-1">
        <a href="#" class="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-zinc-800/60 text-white text-sm font-medium border border-white/[0.05]">
          <i data-lucide="layout-grid" class="w-4 h-4 text-zinc-300"></i>
          <span>Dashboard</span>
        </a>
        <a href="#" class="flex items-center gap-2.5 px-3 py-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-900 text-sm font-medium transition-colors">
          <i data-lucide="shield-alert" class="w-4 h-4 text-zinc-500"></i>
          <span>Security Audit</span>
        </a>
      </nav>
    </div>
  </aside>

  <!-- Main Content -->
  <main class="flex-1 p-8 space-y-8 overflow-y-auto">
    <header class="flex justify-between items-center pb-6 border-b border-white/[0.08]">
      <div>
        <h1 class="text-2xl font-bold tracking-tight text-white">Telemetry Matrix</h1>
        <p class="text-sm text-zinc-400 mt-1">Real-time hardware inspection and process state.</p>
      </div>
      <button class="inline-flex items-center gap-2 bg-white text-zinc-950 hover:bg-zinc-200 active:scale-[0.98] px-4 py-2 rounded-lg text-sm font-semibold transition-all shadow-sm">
        <i data-lucide="refresh-cw" class="w-4 h-4"></i>
        <span>Poll Hardware</span>
      </button>
    </header>

    <!-- Cards Grid -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div class="p-6 rounded-2xl bg-zinc-900/50 border border-white/[0.08] backdrop-blur-xl space-y-3">
        <span class="text-xs font-mono uppercase tracking-wider text-zinc-400">Kernel Hook Status</span>
        <div class="text-3xl font-bold font-mono tracking-tight text-emerald-400 flex items-center gap-2">
          <span>ACTIVE</span>
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
        </div>
        <p class="text-xs text-zinc-500">VMT shadow swap intact.</p>
      </div>
    </div>
  </main>

  <script>
    lucide.createIcons();
  </script>
</body>
</html>
```
