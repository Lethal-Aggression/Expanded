---
name: mcp-server-development
description: >-
  Designing, building, debugging, and integrating Model Context Protocol (MCP) servers.
  Use when creating custom MCP servers in TypeScript, Node.js, Python, or Rust, configuring
  Stdio or Streamable HTTP transports, defining tools/resources/prompts, or connecting
  them to Antigravity.
---

# MCP Server Development Runbook

## 1. Protocol Architecture & Transports
- **Stdio Transport:** Communicates via standard input/output over JSON-RPC 2.0 messages. Ideal for local tools and command-line wrappers.
- **Streamable HTTP Transport:** Communicates over HTTP with `application/json` and `text/event-stream`.
- **JSON-RPC Spec:** Base message format contains `"jsonrpc": "2.0"`, `"id"`, `"method"`, and `"params"`.

## 2. Implementing with Official SDKs

### Python (`mcp` package)
```python
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("CustomService")

@mcp.tool()
def execute_query(query: str) -> str:
    """Execute a specific query against the backend."""
    return f"Result for: {query}"

if __name__ == "__main__":
    mcp.run(transport="stdio")
```

### TypeScript / Node.js (`@modelcontextprotocol/sdk`)
```typescript
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";

const server = new Server({ name: "custom-server", version: "1.0.0" }, { capabilities: { tools: {} } });

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [{
    name: "sample_tool",
    description: "Performs sample action",
    inputSchema: { type: "object", properties: { input: { type: "string" } }, required: ["input"] }
  }]
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  if (request.params.name === "sample_tool") {
    return { content: [{ type: "text", text: `Output: ${request.params.arguments?.input}` }] };
  }
  throw new Error("Tool not found");
});

const transport = new StdioServerTransport();
await server.connect(transport);
```

## 3. Registering in Antigravity
Add the server entry into `~/.gemini/config/mcp_config.json`:

```json
{
  "mcpServers": {
    "my-service": {
      "command": "python",
      "args": ["C:/path/to/server.py"]
    }
  }
}
```
Or for Streamable HTTP:
```json
{
  "mcpServers": {
    "my-http-service": {
      "url": "http://127.0.0.1:8000/mcp",
      "headers": {
        "Authorization": "Bearer <TOKEN>"
      }
    }
  }
}
```

## 4. Verification and Debugging
- Use the MCP Inspector: `npx @modelcontextprotocol/inspector <command> <args>`
- Verify stdin/stdout hygiene: Ensure logging uses `stderr`, never `stdout` in Stdio servers.
